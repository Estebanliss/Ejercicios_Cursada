// DESAFÍO #2

// const HOJA1 = "A4";
// const HOJA2 = "CARTA";
// const HOJA3 = "OFICIO / LEGAL";
// const HOJA4 = "OTRA";

// const ID_HOJA1 = 1;
// const ID_HOJA2 = 2;
// const ID_HOJA3 = 3;
// const ID_HOJA4 = 4;

// const consulta =
//   "¿Qué tamaño de hoja usa con regularidad?:\n" +
//   "1). A4 \n" +
//   "2). CARTA \n" +
//   "3). OFICIO / LEGAL\n" +
//   "4). OTRA \n";
// var resultado;

// var hojaSeleccionada = prompt(consulta);
// hojaSeleccionada = parseInt(hojaSeleccionada);

//comprobacion - ingreso de opcion valida
// while (
//   !(
//     hojaSeleccionada === ID_HOJA1 ||
//     hojaSeleccionada === ID_HOJA2 ||
//     hojaSeleccionada === ID_HOJA3 ||
//     hojaSeleccionada === ID_HOJA4
//   )
// ) {
//   alert("Ingrese un valor válido");
//   hojaSeleccionada = prompt(consulta);
//   hojaSeleccionada = parseInt(hojaSeleccionada);
// }

//proceso final
// if (hojaSeleccionada === ID_HOJA1) {
//   resultado = HOJA1;
// } else if (hojaSeleccionada === ID_HOJA2) {
//   resultado = HOJA2;
// } else if (hojaSeleccionada === ID_HOJA3) {
//   resultado = HOJA3;
// } else if (hojaSeleccionada === ID_HOJA4) {
//   let otroTipo = prompt("Por favor detalle que tamaño de hoja utiliza.");
//   alert(`Usted trabaja con el tamaño de hoja: ${otroTipo}`);
// }
// if (hojaSeleccionada != ID_HOJA4) {
//   alert("Usted trabaja con el tamaño de hoja: " + resultado);
// }

// DESAFÍO #3

let acertijo = prompt(
  "Adivina el siguiente acertijo \n" +
    " \n" +
    "¿Qué monte era el más alto del mundo antes de descubrir el Everest? \n"
);

while (acertijo) {
  if (acertijo === "El Everest") {
    alert("Muy bien, estás aceitado");
    acertijo = false
  } else {
    alert("Intentalo de nuevo");
    acertijo = prompt(
      "Adivina el siguiente acertijo \n" +
        " \n" +
        "¿Qué monte era el más alto del mundo antes de descubrir el Everest? \n"
    );
  }
}
