let nombre = "Esteban";
let apellido =  "Lissandrello";
let edad = 37;

let nombreCompleto = nombre + " " + apellido;




//PROMP


let nombreEstudiante = prompt("Cuál es tu nombre?");

//CONSOLE LOG

console.log(nombreCompleto);
console.log(nombreEstudiante);
